export default {
  gameWidth: 768,
  gameHeight: 480,
  localStorageName: 'prototype1',
  UIpadding: 16
}
