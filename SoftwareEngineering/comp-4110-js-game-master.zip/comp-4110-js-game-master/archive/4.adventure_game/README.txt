1. Use WASD to move.
2. Collect keys and open doors.
