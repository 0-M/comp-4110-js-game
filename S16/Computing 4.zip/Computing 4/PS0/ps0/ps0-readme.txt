/**********************************************************************
 *  ps0-readme template                                                   
 *  Hello World Assignment                       
 **********************************************************************/

Your name: Zachary Krausman

Operating system you're using (Linux, OS X, or Windows): Windows

If Windows, which solution?: MinGw

Text editor or IDE you're using: CodeBlocks

Hours to complete assignment (optional): 1 - 2

/**********************************************************************
 *  List some information (optionally) to help me get to know you.
 **********************************************************************/

Did you take Computing I at UML? Yes

 - If yes, who was your instructor? Sarita Bassil - I don't believe she teaches here anymore.

 - If no, where did you transfer from?



/**********************************************************************
 *  Part of Assignment 0 is to join the course Google group.
 *  Did you do this?
 **********************************************************************/
  I don't see any place to do this.


/**********************************************************************
 *  Another part of Assignment 0 is to read the information on Academic
 *  Integrity at the course home page.
 *
 *  If you haven't done this, please do so now.
 *
 *  Follow the link to the University policy on Academic Integrity,
 *  and answer the following question:
 *
 * There are six examples of academic misconduct, labeled (a) through
 * (f). Other than (a), "Seeks to claim credit for the work or efforts
 * of another without authorization or citation," which of these do you
 * think would most apply to this class, and why? Write approx. 100
 * words.
 *
 * Note: there is no single correct answer to this. I am looking for
 * your opinion.
 **********************************************************************/
  I think (b), "Uses unauthorized materials or fabricated data in any academic exercise".  The main part of this I think is important is the fabricated data.  The point of many programs is to have the  program generate data fabricating data would be like hardcoding something that's supposed to be generated just so that the answer will be correct.  Although Bottlenose might catch this, it's still something that applies to the field.


/**********************************************************************
 *  List whatever help (if any) you received from TAs, the instructor,
 *  classmates, or anyone else.
 **********************************************************************/



/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/



/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

