/* Copyright 2016 Zachary Krausman */
#include "lfsr_class.hpp"


LFSR::LFSR(const char* seed, int t) : tap(t) {  //  constructor to create LFSR
    int temp; ///< will be pushed to vector
    for (unsigned int i = 0; i < strlen(seed); i++) {
        temp = seed[i] - '0';
        registers.push_back(temp);
    }
}
int LFSR::step() {
    int tapBit, shiftedBit, newBit;
    tapBit = registers[registers.size() - tap - 1]; ///< bit to xor
    shiftedBit = registers[0]; ///< empty bit
    newBit = tapBit ^ shiftedBit; ///< xor of tapBit and shiftedBit
    registers.erase(registers.begin());
    registers.push_back(tapBit ^ shiftedBit);
    return newBit;
}
int LFSR::generate(int k) {  //  simulate k steps and return k-bit integer
    int x = 0; ///< k-bit number to return
    for (int i = 0; i < k; i++) {
        int bit = step();
        x = (2 * x) + bit;
    }
    return x;
}

ostream& operator << (ostream& out, LFSR& lfsr) {  // stream insertion operator
    for (unsigned int i = 0; i < lfsr.registers.size(); i++) {
        out << lfsr.registers[i];
    }
    return out;
}


