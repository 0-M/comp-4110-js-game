/** 
 *  @file    lfsr_class.hpp
 *  @author  Zachary Krausman
 *  @date    2/14/16
 *  @version 1.0 
 *  @copyright 2016
 *  @brief Assignment 2-a-a
 *
 *  @section DESCRIPTION
 *  
 *  Linear feedback shift register.
 *
 */


#ifndef LSFR_HPP_INCLUDED
#define LSFR_HPP_INCLUDED

#include <stdlib.h>
#include <cstring>
#include <vector>
#include <iostream>
using std::vector;
using std::ostream;

  /**
  *  @brief Class for linear feedback shift register
  */  
class LFSR {
 protected:
vector<int> registers; ///< vector of integers
int tap;
 public:
  /**  
  *   @brief  Constructor  
  *  
  *   @param  seed is a character array which 
  *   @param  t is an integer
  *   @return nothing
  */ 
LFSR(const char* seed , int t);
  /**  
  *   @brief  simulate one step  
  *  
  *   @return the new bit as 0 or 1
  */ 
int step();
  /**  
  *   @brief simulate k steps and return k-bit integer  
  *  
  *   @param  k is the number of steps and the number of bits the integer should be
  *   @return returns k-bit integer
  */ 
int generate(int k);

friend ostream& operator << (ostream &out, LFSR &lfsr);
};


#endif  // LSFR_HPP_INCLUDED

