/**********************************************************************
 *  ps2a-readme                                                  
 *  Linear Feedback Shift Register partA                       
 **********************************************************************/

Your name: Zachary Krausman

Operating system you're using (Linux, OS X, or Windows): Linux

Hours to complete assignment (optional): < 2


/**********************************************************************
 *  Representation I used for the register bits explanation.
 **********************************************************************/
	For the register bits I used a vector.  I used a vector because they are very easy to add and remove from, and it makes it easier than suing an array because I don't know how long the string is going to be os if I want to use an array I would've had to have made a pointer then allocated space for it once the string was passed.  Although this is more memory efficient it is much more annoying to code.  I put all the bits in the vector by pulling a character from the string (which is an array of characters so you can just do string[i], then subtracting the character 0 from it, which will make any character that's a number into that number.

/**********************************************************************
 *  What's being tested in my test cases.                
 **********************************************************************/
	My test cases simply test long strings and short strings, making sure that the size of the string doesn't affect my program as long as the string is at least one bit and no greater than 32 bits.  Because my program splits the string up, my program will accept a string that is longer than 32 bits.  However, except for small strings and regardless of what tap you pick, if you generate enough times you will get a negative (if the number of times you generate is odd and over 32, you will most likely get a negative number.  I also noticed some weird behavior if you pick 0 as your tap bit.  This is because the tap bit is changing in a different pattern than other bits.

