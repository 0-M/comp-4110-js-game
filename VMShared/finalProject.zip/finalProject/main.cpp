#include "space.hpp"

int main(int argc, char* argv[]) {
space::Star x(5,5,5);
return 0;
}
