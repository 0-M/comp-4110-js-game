/**********************************************************************
 *  ps1-readme template                                                   
 *  Sierpinski Triangles                      
 **********************************************************************/

Your name: Zachary Krausman

Operating system you're using (Linux, OS X, or Windows): Linux

Hours to complete assignment (optional): 4

/**********************************************************************
 *  What I did
 **********************************************************************/
   For my original design I made a snowflake design.  I function created six lines that were    drawn at every PI/3.  Each level of recursion will draw six lines around each endpoint.  So level one will have 6 lines, two will 36(6^2) lines and 3 will have 216 lines (6^3).  The function will call its self six times because the function will have to be called 6 times for each line generated in the last level of recursion.  
  


/**********************************************************************
 *  Why inheriting from sf::Drawable allows window.draw(object) to work
 **********************************************************************/
  It's because window.draw() has an argument drawable so it makes it easy when you ingerit from sf::Drawable.  If you don't inherit from sf::Drawable, you have to use the syntax object.draw(window) where your object will take the window as an argument.  In the first syntax you are passing what should be drawn to the window.  In the second syntax you are passing the window to what needs to be drawn.  If you do object.draw(window), you're eventually going to be calling window.draw(object) the first syntax just hands it directly.

/**********************************************************************
 *  How much memory each of the programs uses depending on the recursion depth
 **********************************************************************/
	The programs use exponentially more depending on the recursion depth.  Each layer of recursion has exponentially more operations than the last layer.  I used vectors to hold what would eventually be drawn.  I didn't set the size of the vector which means that it has to allocate memory for every operation which is very costly.


/**********************************************************************
 *  List whatever help (if any) you received from TAs, the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
  none

