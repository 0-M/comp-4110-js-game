#include <stdio.h>
#include <stdlib.h>
#include "BlackJack.h"

#define MAX_BET 1000

int main(int argc, char *argv[])
{
    DeckPtr deck = makeDeck(2);
    Player player;
    Dealer dealer;
    player.hand.inHand = 0;
	player.cash = 1000;
    dealer.hand.inHand = 0;
    deck = shuffleCards(deck);

	/*Debug functions*/
    //printDeck(deck);
	//printf("\n%d\n", deck->cardsLeft);
	playBlackjack(deck, dealer, player);

	empty(deck);
	destroyDeck(deck);

    return 0;
}

DeckPtr makeDeck(int numberOfDecks)
{
	Card newCard;
    DeckPtr deck = initDeck(numberOfDecks);

    int i;
    int j;
	int h;
	int count;
    count = 0;

	for(h = 0; h < numberOfDecks; h++)
	{
		for(j = 3; j < 7; j++)
		{
			for(i = 1; i < 14; i++)
			{
				newCard.value = i;
				newCard.suit = j;
				newCard.faceUp = 1;
				push(deck, newCard);
				count++;
			}
		}
	}
    return deck;
}

void playBlackjack(DeckPtr deck, Dealer dealer, Player player)
{
	int bet;
	int choice;
	int dealerTotal;
	int playerTotal;

	while(1)
	{
		/***Ask for bets***/
		printf("Your Life's Worth: $%d\n", player.cash);
		printf("Place your bet:\n");
		scanf("%d", &bet);
		while(bet > MAX_BET || bet > player.cash)
		{
			printf("Bet is too high! Please re-enter your bet for this round.\n");
			scanf("%d", &bet);
		}

		/***Deal Cards***/
		//dealCard() twice for dealer
		dealCard(deck, &(dealer.hand));//This card is face up
		dealCard(deck, &(dealer.hand));//This card will be face down
		dealer.hand.hand[1].faceUp = 0;
		printf("Dealer's hand:\t");
		printHand(&(dealer.hand));
		printf("\nDealer has one other face-down card...\n\n");
	
		//dealCard() twice for player
		dealCard(deck, &(player.hand));
		dealCard(deck, &(player.hand));
		printf("Your hand:\t");
		printHand(&(player.hand));
		printf("\n\n");

		dealerTotal = checkForBlackjack(dealer.hand);
		playerTotal = checkForBlackjack(player.hand);

		if(dealerTotal < 21 || playerTotal < 21)
		{
			/***First play options are to double, hit, or stand***/
			printf("Your options are to double [1], hit [2], stand [3], or split [4]\n");
			scanf("%d", &choice);
			while(choice < 1 || choice > 4)
			{
				printf("Try again: Your options are to double [1], hit [2], stand [3], or split [4]\n");
				scanf("%d", &choice);
			}
		}
		else
		{
			if(dealerTotal == 21 && playerTotal < 21)
			{
				printf("You lost! Dealer has blackjack.\n");
				break;
			}
			else if (dealerTotal < 21 && playerTotal == 21)
			{
				printf("You have blackjack!\n");
				break;
			}
		}

		//if option is to double:
		if(choice == 1)
		{
			dealCard(deck, &(player.hand));
			dealerTotal = checkForBlackjack(dealer.hand);
			playerTotal = checkForBlackjack(player.hand);
			if(dealerTotal > playerTotal)
			{
				if(dealerTotal < 21)
				{
					printf("You lost!\n");
				}
			}
			else if(playerTotal > dealerTotal)
			{
				
			}
		}

		//if option is to hit:
		if(choice == 2)
		{
	
		}

		//if option is to stand:
		if(choice == 3)
		{
	
		}

		//if option is to split:
		if(choice == 4)
		{
	
		}

		/*Subsequent plays in the round are to hit or stand*/
	
		/*Check after every round*/

		//if player is under 21:
		//
		//keep looping

		//if player is at 21:
		//
		//Blackjack. stop loop and end game

		//if player is over 21:
		//
		//Bust. stop loop and end game
	}
}

int checkForBlackjack(Hand hand)
{
	int i;
	int hasAce = 0;
	int total = 0;

	for(i = 0; i < hand.inHand; i++)
	{
		if (hand.hand[i].value == 11 || hand.hand[i].value == 12 || hand.hand[i].value == 13)
		{
			total += 10;
		}
		else if (hand.hand[i].value == 1 && hasAce == 0)
		{
			hasAce = 1;
			total += 11;
		}
		else
		{
			total += hand.hand[i].value;
		}
	}

	if(total > 21 && hasAce == 1)
	{
		total -= 10;
	}

	return total;
}